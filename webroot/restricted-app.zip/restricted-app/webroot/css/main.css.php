<?php

header('Content-type: text/css; charset=utf-8');

?>
body {
	margin: 0;
	padding: 0;
}
body, p, div, #tab-landing {
	font-family: "Lucida Grande", Verdana, Arial, sans-serif;
}
body, #tab-landing {
	margin: 0;
}

h2 {
	font-size: 18px;
}

p {
	font-size: 14px;
}

p.info {
	font-size: 10px;
}

.debug pre {
	width: 520px;
	overflow: auto;
	padding: 0;
	margin: 0;
}

